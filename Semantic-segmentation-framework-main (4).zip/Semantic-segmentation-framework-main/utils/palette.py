CLASSES=('ignore','impervious_surface', 'building', 'low_vegetation', 'tree',
               'car', 'clutter')
PALETTE=[
        [0, 0, 0],[255, 255, 255], [0, 0, 255], [0, 255, 255], [0, 255, 0],
        [255, 255, 0], [255, 0, 0]
]